package com.example.demo.domain;


/**
 * @author Glenn
 * @version 1.0
 * @created 15-Mar-2019 18:40:44
 */
public interface Klant {
	void setNaam(String naam);
	String getNaam();
}//end Klant