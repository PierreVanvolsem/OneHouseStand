package domain;


import java.util.Date;

/**
 * @author Fabian
 * @version 1.0
 * @created 15-Mar-2019 18:40:44
 */
public class Mat {

	private double aankoopPrijs;
	private Date laatstGecheckt;
	private int productNummer;
	private String status;

	public Mat(){

	}

	public void herstel(){

	}

	public void markeerAlsVersleten(){

	}

}//end Mat