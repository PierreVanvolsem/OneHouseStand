package domain;


import java.util.List;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:10:22
 */
public class Aanvraag {

	private Enum status;
	public static List<Aanvraag> aanvragen;
	private Gebruiker gebruiker;
	private List<String> kenmerken;
	private Pand pand;
	public Pand m_Pand;
	public Gebruiker m_Gebruiker;



	public void finalize() throws Throwable {

	}
	public Aanvraag(){

	}

	public void keurAf(){

	}

	public void keurGoed(){

	}
}//end Aanvraag