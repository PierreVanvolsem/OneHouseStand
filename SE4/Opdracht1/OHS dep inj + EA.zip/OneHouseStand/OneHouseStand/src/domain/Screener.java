package domain;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:09:04
 */

@Component("screener")
public class Screener implements Persoon {

    private int teVerwerkenAanvragen;
    private List<Review> teVerwerkenReviews;
    public Aanvraag m_Aanvraag;
    public Review m_Review;

    public Screener() {

    }

    public void finalize() throws Throwable {
        super.finalize();
    }

    /**
     * @param aanvraag
     * @param oordeel
     */
    public void keurPand(Aanvraag aanvraag, Boolean oordeel) {

    }

    /**
     * @param pand
     */
    public void updatePand(Pand pand) {

    }

    /**
     * @param pandid
     */
    public Pand zoekPand(int pandid) {
        return null;
    }


    private String _naam = "Andre de screener";

    @Autowired
    public void setScreenerNaam(String setSreenerNaam) {
        this._naam = setSreenerNaam;
    }

    @Override
    public void setNaam(String naam) {
        this._naam = naam;
    }

    @Override
    public String getNaam() {
        return _naam;
    }
}//end Screener