package domain;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:09:26
 */
@Component("gebruiker")
public class Gebruiker implements Persoon {

    private List<Aanvraag> aanvragen;
    private List<Review> geschrevenReviews;
    private List<Pand> panden;
    private List<Reservatie> reservaties;
    public Review m_Review;
    public Pand m_Pand;


    public void finalize() throws Throwable {
        super.finalize();
    }

    public Gebruiker() {

    }

    /**
     * @param kenmerken
     */
    public Aanvraag verstuurAanvraag(List<String> kenmerken) {
        return null;
    }

    /**
     * @param pand
     * @param begindatum
     * @param einddatum
     */
    public Reservatie reserveer(Pand pand, Date begindatum, Date einddatum) {
        return null;
    }

    /**
     * @param reservatie
     * @param mening
     */
    public Review review(Reservatie reservatie, String mening) {
        return null;
    }


    private String _naam = "Bob de gebruiker";

    @Autowired
    public void setGebruikerNaam(String setGebruikerNaam) {
        this._naam = setGebruikerNaam;
    }

    @Override
    public void setNaam(String naam) {
        this._naam = naam;
    }

    @Override
    public String getNaam() {
        return _naam;
    }
}//end Gebruiker