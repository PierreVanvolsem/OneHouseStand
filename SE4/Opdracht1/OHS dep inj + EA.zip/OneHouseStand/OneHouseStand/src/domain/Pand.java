package domain;


/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:09:42
 */
public class Pand {

	private String huisNummer;
	private Mat matten;
	private Double prijsPerUur;
	private Reservatie reservaties;
	private Enum status;
	private String straatNaam;
	private Syndicus syndicus;
	private String bron;
	private Gebruiker eigenaar;
	public Mat m_Mat;
	public Syndicus m_Syndicus;

	public Pand(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(String status){

	}
}//end Pand