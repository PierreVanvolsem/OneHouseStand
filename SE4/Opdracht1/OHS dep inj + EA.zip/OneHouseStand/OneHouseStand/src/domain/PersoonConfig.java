package domain;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class PersoonConfig {
    @Bean
    public String setSreenerNaam() {
        return "Hallo...(ich bin screener)";
    }

    @Bean
    public String setGebruikerNaam() {
        return "mijn naam is veranderd, nu heet ik jan";
    }

    @Bean
    public String setSyndicusNaam() {
        return "mijn naam is veranderd in gierige job";
    }
}