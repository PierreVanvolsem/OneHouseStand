package domain;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:08:07
 */


@Component("syndicus")
public class Syndicus implements Persoon {

    private Pand teBeherenPanden;

    public Syndicus() {

    }

    public void finalize() throws Throwable {
        super.finalize();
    }

    /**
     * @param email
     * @param probleem
     */
    public void verzendProbleem(String email, String probleem) {

    }

    private String _naam = "Tina de syndicus";

    @Autowired
    public void setSyndicusNaam(String setSyndicusNaam) {
        this._naam = setSyndicusNaam;
    }

    @Override
    public void setNaam(String naam) {
        _naam = naam;
    }

    @Override
    public String getNaam() {
        return _naam;
    }
}//end Syndicus