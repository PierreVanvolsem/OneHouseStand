package domain;


import domain.Pand;

import java.util.Date;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:08:44
 */
public class Reservatie {

	private Date eindDatum;
	private Boolean isGeannuleerd;
	private Date startDatum;
	private Pand pand;
	private Gebruiker huurder;
	public Gebruiker m_Gebruiker;
	public Pand m_Pand;

	public Reservatie(){

	}

	public void finalize() throws Throwable {

	}

}//end Reservatie