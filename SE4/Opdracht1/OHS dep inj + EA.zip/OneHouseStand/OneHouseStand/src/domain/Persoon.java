package domain;

public interface Persoon {
    void setNaam(String naam);
    String getNaam();
}
