package domain;


import java.util.Date;
import java.util.List;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:10:48
 */
public class Review {

	private String content;
	private Date datum;
	private Gebruiker gebruiker;
	private Pand pand;
	private int rating;
	private Enum status;
	public static List<Review> reviews;
	public Pand m_Pand;



	public void finalize() throws Throwable {

	}
	public Review(){

	}

	public void verberg(){

	}

	public void verwerk(){

	}
}//end Review