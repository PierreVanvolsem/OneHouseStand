package domain;


import java.util.Date;

/**
 * @author Fabian
 * @version 1.0
 * @created 05-mars-2019 10:10:02
 */
public class Mat {

	private double aankoopPrijs;
	private Date laatstGecheckt;
	private Enum status;
	private int productNummer;

	public Mat(){

	}

	public void finalize() throws Throwable {

	}
	public void herstel(){

	}

	public void markeerAlsVersleten(){

	}
}//end Mat