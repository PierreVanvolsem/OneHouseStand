package domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Main {

    public  static Persoon screener, gebruiker, syndicus;

    private static ApplicationContext applicationContext;

    @Autowired
    public  Main(Persoon screener, Persoon gebruiker, Persoon syndicus) {
        Main.screener = screener;
        Main.gebruiker = gebruiker;
        Main.syndicus = syndicus;
    }

    public static void main(String[] args) {
        System.out.println("Starting....");

        applicationContext = new AnnotationConfigApplicationContext(PersoonConfig.class);

        System.out.println("Spring context initialized.");
        System.out.println("p1='" + screener.getNaam());
        System.out.println("p2='" + gebruiker.getNaam());
        System.out.println("p3='" + syndicus.getNaam());
    }
}
