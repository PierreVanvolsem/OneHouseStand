package service;

import domain.Review;
import domain.Aanvraag;


/**
 * @author trelu
 * @version 1.0
 * @created 05-mars-2019 10:06:05
 */
public class OhsServiceImplementatie implements OhsService {

	@Override
	public Aanvraag reserveren(String Aanvraag, String Gebruiker) {
		return null;
	}

	@Override
	public Aanvraag verhuurAanvraag(String Aanvraag, String Gebruiker) {
		return null;
	}

	@Override
	public Review addReview(String Review, String Gebruiker, String string) {
		return null;
	}

	@Override
	public boolean aanvraagVerwerken(String Aanvraag, String Screener) {
		return false;
	}

	@Override
	public boolean reviewVerwerken(String Review, String Screener) {
		return false;
	}

	@Override
	public boolean pandZoeken(String Pand) {
		return false;
	}

	@Override
	public String probleemMelden(String String, String Syndicus) {
		return null;
	}
}//end OhsServiceImplementatie