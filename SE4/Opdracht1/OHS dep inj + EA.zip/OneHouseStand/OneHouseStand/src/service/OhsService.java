package service;


import domain.Aanvraag;
import domain.Review;

/**
 * @author trelu
 * @version 1.0
 * @created 05-mars-2019 10:07:27
 */
public interface OhsService {

	/**
	 * 
	 * @param Aanvraag
	 * @param Gebruiker    Gebruiker
	 */
	public Aanvraag reserveren(String Aanvraag, String Gebruiker);

	/**
	 * 
	 * @param Aanvraag
	 * @param Gebruiker    Gebruiker
	 */
	public Aanvraag verhuurAanvraag(String Aanvraag, String Gebruiker);

	/**
	 * 
	 * @param Review
	 * @param Gebruiker
	 * @param string    string
	 */
	public Review addReview(String Review, String Gebruiker, String string);

	/**
	 * 
	 * @param Aanvraag
	 * @param Screener    Screener
	 */
	public boolean aanvraagVerwerken(String Aanvraag, String Screener);

	/**
	 * 
	 * @param Review
	 * @param Screener    Screener
	 */
	public boolean reviewVerwerken(String Review, String Screener);

	/**
	 * 
	 * @param Pand    Pand
	 */
	public boolean pandZoeken(String Pand);

	/**
	 * 
	 * @param String
	 * @param Syndicus    Syndicus
	 */
	public String probleemMelden(String String, String Syndicus);

}